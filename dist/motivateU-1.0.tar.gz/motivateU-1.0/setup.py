from distutils.core import setup

if __name__ == "__main__":
    setup( name = "motivateU",\
            version = "1.0",\
        )
        